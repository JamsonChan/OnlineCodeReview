def Homework_2(matrix:list[list[int]] , y:int, x:int):





    return 0

if __name__ == "__main__":  # 請記得將檔名改成 s+學號 (ex. s1104813.py)
    call_func = Homework_2([[3,4],[5,6]], 1, 4)
    print(call_func)  # [[[3, 4, 5, 6]], True]
