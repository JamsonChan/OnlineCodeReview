import os,sys,time,copy
from guppy import hpy
from capital_measurement import hw2_IN as In, hw2_ANS as Ans
# ------------------------------------ # 抓取檔案名稱
now = os.getcwd()
dic = os.listdir(now)
for i in dic:
    if i.split(".py")[0][1:].isdecimal():
        student_file = i.split(".py")[0]
# ------------------------------------ # 加入環境變數
sys.dont_write_bytecode = True
sys.path.append(os.getcwd())
exec(f"from {student_file} import Homework_2 as func")
# ------------------------------------ # 加入環境變數
topic = copy.deepcopy(In)
frequency = 1  # 循環次數
score = 0  # 基本分
# avg = 25  # 一題幾分
avg = 100 // len(In)  # 一題幾分
error = list()
student_error = list()
now = time.time()  # 時間複雜度
heap = hpy()
heap.setref()
heap_status1 = heap.heap()  # 堆疊起點
for f in range(frequency):
    for i in range(len(In)):
        try:
            student_Ans = func(topic[i][0], topic[i][1], topic[i][2])
        except Exception as ex:  # 顯示 error 名稱:
            if f == 0:
                error.append(i)
                student_error.append(f"{ex.__class__.__name__}:{str(ex)}")
            continue
        if student_Ans == Ans[i]:
            if f == 0:
                score += avg
        else:
            if f == 0:
                error.append(i)
                student_error.append(student_Ans)
heap_status2 = heap.heap()  # 堆疊終點
print()
# ------------------------------------ # 顯示學生錯誤題目
if len(error) != 0:
    print(f"您錯了:{len(error)}題")
    print(f"分數 : {score} 分")
    print('------------------------顯示錯誤題目-------------------------')
    for i in range(len(error)):
        print(f"第{error[i]+1}題答錯了!")
        print(f"答錯的題目:{In[error[i]]}")
        print(f"您的答案:{student_error[i]}")
        print(f"正確答案:{Ans[error[i]]}")
        print('============================================')
else:
    print('--------------------------恭喜您全對!---------------------------')
    print(f"所花時間 : {round((time.time()-now)*1000, 2)} ms")
    print(f"所使用記憶體 : {heap_status2.size/1024**2} MB")
    print(f"分數 : {score} 分")
    print(f"記憶體使用資訊 : \n{heap_status2}")  # 從 第5行 - 第14行
print('-------------------------------------------------------------')
input()