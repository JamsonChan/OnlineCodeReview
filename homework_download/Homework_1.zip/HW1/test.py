class Homework1:  # 資料結構 (作業1 : 請勿更改類別和方法名稱)
    def __init__(self, list1, list2, parameter1, parameter2):  # 初始化函式 (請建立類別變數)
        self.list1 = list(list1)  # --! 請使用此變數，請勿更改 !--
        self.list2 = list(list2)  # --! 請使用此變數，請勿更改 !--

    def division_list1(self):  # 除法函式 (將 list1 每個數值整除 parameter1) 


    def multiplication_list2(self):  # 乘法函式 (將 list2 每個數值乘以 parameter2)


    def remainder_list1_and_list2(self):  # 餘數函式 (將 list1 除以 list2 的餘數存到一個新的陣列並回傳)


        return
        
if __name__ == "__main__":  # 請勿刪掉這行
    call_class = Homework1([1,2,3,4,5] , [1,2,3,4,5], 2, 5)
    call_class.division_list1()
    call_class.multiplication_list2()
    print(call_class.remainder_list1_and_list2())  # Ans : [0, 1, 1, 2, 2]
